#include <string>
#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{
    if (argc != 3) return(0);
    string sQuantity = argv[1];
    string sPrice = argv[2];

    cout << stof(sQuantity) * stof(sPrice);

    return(0);
}
